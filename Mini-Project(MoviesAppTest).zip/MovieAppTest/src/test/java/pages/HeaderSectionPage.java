package pages;

public class HeaderSectionPage {
}
