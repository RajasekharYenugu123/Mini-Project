package pages;

public class MovieDetailsPage {
}
