package pages;

public class SearchPage {
}
