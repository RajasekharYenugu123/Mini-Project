package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;


public class SearchPageTest {

    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Set the path to your ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rajasekhar\\Downloads\\chromedriver-win32\\chromedriver.exe");
        // Initialize ChromeDriver
        driver = new ChromeDriver();
        // Navigate to the search page or your application's home page
        driver.get("https://qamoviesapp.ccbp.tech/login");

        WebElement usernameEl = driver.findElement(By.id("usernameInput"));
        usernameEl.sendKeys("rahul");

        WebElement passwordEl = driver.findElement(By.id("passwordInput"));
        passwordEl.sendKeys("rahul@2021");

        WebElement loginButtonEl = driver.findElement(By.className("login-button"));
        loginButtonEl.submit();
    }

    @Test
    public void testSearchFunctionality() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        // Navigate to the page
        driver.get("https://qamoviesapp.ccbp.tech/search");

        // Locate the button element using its class name
        WebElement searchButton = driver.findElement(By.className("search-button"));

        // Perform an action on the button, click
        searchButton.click();

        WebElement searchInput = driver.findElement(By.id("search"));
        searchInput.sendKeys("Dune");
        searchInput.sendKeys(Keys.ENTER);

        // Wait for search results container to be visible
        WebElement searchResultsContainer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("search-container")));
        List<WebElement> searchResults = searchResultsContainer.findElements(By.className("search-movies-container"));
        int actualMovieCount = searchResults.size();
        int expectedMovieCount = 1;

        // Redirect to the movie details page
        driver.get("https://qamoviesapp.ccbp.tech/");

        // Print redirect message
        System.out.println("Redirecting to the movie details page...");
    }

    @AfterClass
    public void tearDown() {
        // Close the browser window
        if (driver != null) {
            driver.quit();
        }
    }
}
