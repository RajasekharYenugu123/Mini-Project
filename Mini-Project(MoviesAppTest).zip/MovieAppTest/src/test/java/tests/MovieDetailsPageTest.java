package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



import org.testng.Assert;
import java.time.Duration;
import java.util.List;

public class MovieDetailsPageTest {

    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Set the path to your ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rajasekhar\\Downloads\\chromedriver-win32\\chromedriver.exe");
        // Initialize ChromeDriver
        driver = new ChromeDriver();
        // Navigate to the search page or your application's home page
        driver.get("https://qamoviesapp.ccbp.tech/login");

        // Perform login (you can modify this part based on your authentication mechanism)
        WebElement usernameEl = driver.findElement(By.id("usernameInput"));
        usernameEl.sendKeys("rahul");

        WebElement passwordEl = driver.findElement(By.id("passwordInput"));
        passwordEl.sendKeys("rahul@2021");

        WebElement loginButtonEl = driver.findElement(By.className("login-button"));
        loginButtonEl.submit();
    }

    @Test
    public void testMovieDetailsPageUIElements() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));


        // Click on any movie
        WebElement movieLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='root']/div/div[2]/div[1]/div/div/div/div/div[1]/div/a")));
        movieLink.click();

        // Wait for the movie details page to load
        String expectedTitle = "movie-title";  // Replace with the actual title
        System.out.println("Waiting for the title to contain: " + expectedTitle);

        try {
            WebElement movieTitleElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("movie-title")));
            System.out.println("Movie Title: " + movieTitleElement.getText());
        } catch (TimeoutException e) {
            System.out.println("TimeoutException: Movie title element not found within the specified timeout.");
            throw e;
        }
        WebElement movieDescription = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[1]/p"));
        Assert.assertTrue(movieDescription.isDisplayed(), "Movie description is not displayed");
        System.out.println("Movie Description: " + movieDescription.getText());



        // Check if the movie release date is displayed
        WebElement releaseDateElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[1]/div/p[3]"));
        Assert.assertTrue(releaseDateElement.isDisplayed(), "Release date is not displayed");
        System.out.println("Release Date: " + releaseDateElement.getText());

// Check if the movie sensor rating is displayed
        WebElement SensorRatingElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[1]/div/p[2]"));
        Assert.assertTrue(SensorRatingElement.isDisplayed(), "Movie rating is not displayed");
        System.out.println("Movie Rating: " + SensorRatingElement.getText());

// Check if the movie watchTime is displayed
        WebElement watchTimeElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[1]/div/p[1]"));
        Assert.assertTrue(watchTimeElement.isDisplayed(), "Movie watchTime is not displayed");
        System.out.println("Movie time: " + watchTimeElement.getText());

        // Check if the movie genres are displayed
        List<WebElement> genreElements = driver.findElements(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[1]/div"));
        for (WebElement genreElement : genreElements) {
            Assert.assertTrue(genreElement.isDisplayed(), "Genre information is not displayed");
            System.out.println("Genre: " + genreElement.getText());
        }

// Check if the audio languages are displayed
        List<WebElement> audioLanguages = driver.findElements(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[2]/ul"));
        for (WebElement audioLanguage : audioLanguages) {
            Assert.assertTrue(audioLanguage.isDisplayed(), "Audio language information is not displayed");
            System.out.println("Audio Language: " + audioLanguage.getText());
        }

// Check if the rating count is displayed
        WebElement ratingCountElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[3]/p[1]"));
        Assert.assertTrue(ratingCountElement.isDisplayed(), "Rating count is not displayed");
        System.out.println("Rating Count: " + ratingCountElement.getText());

// Check if the average rating is displayed
        WebElement ratingAverageElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[3]/p[2]"));
        Assert.assertTrue(ratingAverageElement.isDisplayed(), "Average rating is not displayed");
        System.out.println("Rating Average: " + ratingAverageElement.getText());

// Check if the budget information is displayed
        WebElement budgetElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[4]/p[1]"));
        Assert.assertTrue(budgetElement.isDisplayed(), "Budget information is not displayed");
        System.out.println("Budget: " + budgetElement.getText());

        // Redirect to the movie details page
        driver.get("https://qamoviesapp.ccbp.tech/");

        // Print redirect message
        System.out.println("Redirecting to the movie details page...");

    }


    @Test
    public void testMovieDetailsPageUIElementsAfterClickingOnPopularMovie() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Navigate to the Popular page
        driver.get("https://qamoviesapp.ccbp.tech/popular");

        // Click on any popular movie
        WebElement popularMovieLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[1]/li[1]/a")));
        popularMovieLink.click();

        // Wait for the movie details page to load
        String expectedTitle = "movie-title";  // Replace with the actual title
        System.out.println("Waiting for the title to contain: " + expectedTitle);

        try {
            WebElement movieTitleElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("movie-title")));
            System.out.println("Movie Title: " + movieTitleElement.getText());
        } catch (TimeoutException e) {
            System.out.println("TimeoutException: Movie title element not found within the specified timeout.");
            throw e;
        }

        // Add assertions and print statements for other UI elements on the Movie Details Page
        WebElement movieDescription = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[1]/p"));
        Assert.assertTrue(movieDescription.isDisplayed(), "Movie description is not displayed");
        System.out.println("Movie Description: " + movieDescription.getText());




        // Check if the movie release date is displayed
        WebElement releaseDateElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[1]/div/p[3]"));
        Assert.assertTrue(releaseDateElement.isDisplayed(), "Release date is not displayed");
        System.out.println("Release Date: " + releaseDateElement.getText());

// Check if the movie sensor rating is displayed
        WebElement SensorRatingElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[1]/div/p[2]"));
        Assert.assertTrue(SensorRatingElement.isDisplayed(), "Movie rating is not displayed");
        System.out.println("Movie Rating: " + SensorRatingElement.getText());

// Check if the movie watchTime is displayed
        WebElement watchTimeElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[1]/div/p[1]"));
        Assert.assertTrue(watchTimeElement.isDisplayed(), "Movie watchTime is not displayed");
        System.out.println("Movie time: " + watchTimeElement.getText());

        // Check if the movie genres are displayed
        List<WebElement> genreElements = driver.findElements(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[1]/div"));
        for (WebElement genreElement : genreElements) {
            Assert.assertTrue(genreElement.isDisplayed(), "Genre information is not displayed");
            System.out.println("Genre: " + genreElement.getText());
        }

// Check if the audio languages are displayed
        List<WebElement> audioLanguages = driver.findElements(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[2]/ul"));
        for (WebElement audioLanguage : audioLanguages) {
            Assert.assertTrue(audioLanguage.isDisplayed(), "Audio language information is not displayed");
            System.out.println("Audio Language: " + audioLanguage.getText());
        }

// Check if the rating count is displayed
        WebElement ratingCountElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[3]/p[1]"));
        Assert.assertTrue(ratingCountElement.isDisplayed(), "Rating count is not displayed");
        System.out.println("Rating Count: " + ratingCountElement.getText());

// Check if the average rating is displayed
        WebElement ratingAverageElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[3]/p[2]"));
        Assert.assertTrue(ratingAverageElement.isDisplayed(), "Average rating is not displayed");
        System.out.println("Rating Average: " + ratingAverageElement.getText());

// Check if the budget information is displayed
        WebElement budgetElement = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div[4]/p[1]"));
        Assert.assertTrue(budgetElement.isDisplayed(), "Budget information is not displayed");
        System.out.println("Budget: " + budgetElement.getText());

        // Redirect to the movie details page
        driver.get("https://qamoviesapp.ccbp.tech/");

        // Print redirect message
        System.out.println("Redirecting to the movie details page...");

    }
    @AfterClass
    public void tearDown() {
        // Close the browser window
        if (driver != null) {
            driver.quit();
        }
    }
}
