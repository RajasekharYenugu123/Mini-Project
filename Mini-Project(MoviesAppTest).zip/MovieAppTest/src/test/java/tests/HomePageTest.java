package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import static org.testng.Assert.*;
import java.util.List;




public class HomePageTest {
    public WebDriver driver;

    @BeforeMethod
    public void setup() {


        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rajasekhar\\Downloads\\chromedriver-win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://qamoviesapp.ccbp.tech/login");

        WebElement usernameEl = driver.findElement(By.id("usernameInput"));
        usernameEl.sendKeys("rahul");

        // Locate password web element
        WebElement passwordEl = driver.findElement(By.id("passwordInput"));
        passwordEl.sendKeys("rahul@2021");

        // Locate Button web element and click
        WebElement loginButtonEl = driver.findElement(By.className("login-button"));
        loginButtonEl.submit();
    }

    @Test(priority = 1)
    public void testHeadingTexts1() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement section1Heading = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]/h1")));

        // Example assertion for heading text
        assertEquals(section1Heading.getText(), "Trending Now", "Section 1 heading text is incorrect");
        System.out.println("Test Heading Texts 1 executed.");

    }
    @Test(priority = 2)
    public void testHeadingTexts2() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement section1Heading = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/h1")));

        // Example assertion for heading text
        assertEquals(section1Heading.getText(), "Originals", "Section 1 heading text is incorrect");
        System.out.println("Test Heading Texts 2 executed.");

    }

    @Test(priority = 3)
    public void testPlayButtonDisplayed() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement playButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[1]/div/button")));

        // Example assertion for play button visibility
        assertTrue(playButton.isDisplayed(), "Play button is not displayed");
    }

    @Test(priority = 4)
    public void testMoviesDisplayed() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Locate the Trending Now section
        WebElement trendingNowSection = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]/div/div/div/div/div[1]/div")));

        // Get all individual movie elements within the Trending Now section
        List<WebElement> trendingNowMovies = trendingNowSection.findElements(By.xpath("//*[@id=\"root\"]/div/div[2]/div[1]/div/div/div/div/div[1]/div/a/div/img"));

        // Example assertion and print for each movie's visibility in Trending Now
        for (WebElement movie : trendingNowMovies) {
            boolean isDisplayed = movie.isDisplayed();
            assertTrue(isDisplayed, "Individual movie in Trending Now is not displayed");
            System.out.println("Movie in Trending Now is displayed: " + isDisplayed);
        }

        // Locate the Originals section
        WebElement originalsSection = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div/div/div/div/div[1]/div")));

        // Get all individual movie elements within the Originals section
        List<WebElement> originalsMovies = originalsSection.findElements(By.xpath("//*[@id=\"root\"]/div/div[2]/div[2]/div/div/div/div/div[1]/div/a/div/img"));

        // Example assertion and print for each movie's visibility in Originals
        for (WebElement movie : originalsMovies) {
            boolean isDisplayed = movie.isDisplayed();
            assertTrue(isDisplayed, "Individual movie in Originals is not displayed");
            System.out.println("Movie in Originals is displayed: " + isDisplayed);
        }
    }



    @Test(priority = 5)
    public void testContactUsSection() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Wait for the Contact Us section to be visible
        WebElement contactUsSection = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/p")));

        // Example assertion for contact us section text
        assertEquals(contactUsSection.getText(), "Contact Us", "Contact us section text is incorrect");

        // Check if Google icon is visible
        assertTrue(isElementVisible(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/div")), "Google icon is not visible");

        // Check if Twitter icon is visible
        assertTrue(isElementVisible(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/div")), "Twitter icon is not visible");

        // Check if Instagram icon is visible
        assertTrue(isElementVisible(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/div")), "Instagram icon is not visible");

        // Check if YouTube icon is visible
        assertTrue(isElementVisible(By.xpath("//*[@id=\"root\"]/div/div[2]/div[3]/div")), "YouTube icon is not visible");
    }

    private boolean isElementVisible(By locator) {
        try {
            WebElement element = driver.findElement(locator);
            return element != null && ExpectedConditions.visibilityOfElementLocated(locator).apply(driver) != null;
        } catch (org.openqa.selenium.NoSuchElementException | org.openqa.selenium.StaleElementReferenceException e) {
            return false;
        }
    }

    @AfterMethod
    public void teardown() {

        driver.quit();
    }
}
