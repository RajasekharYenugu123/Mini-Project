package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;

public class AccountsPageTest {

    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Set the path to your ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rajasekhar\\Downloads\\chromedriver-win32\\chromedriver.exe");
        // Initialize ChromeDriver
        driver = new ChromeDriver();
        // Navigate to the login page
        driver.get("https://qamoviesapp.ccbp.tech/login");

        // Perform login
        WebElement usernameEl = driver.findElement(By.id("usernameInput"));
        usernameEl.sendKeys("rahul");

        WebElement passwordEl = driver.findElement(By.id("passwordInput"));
        passwordEl.sendKeys("rahul@2021");

        WebElement loginButtonEl = driver.findElement(By.className("login-button"));
        loginButtonEl.submit();
    }

    @Test (priority = 1)
    public void testUIElementsOnAccountPage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Navigate to the Account page
        driver.get("https://qamoviesapp.ccbp.tech/account");

        //  Test the visibility of the account information element
        WebElement accountInfoElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[1]")));
        Assert.assertTrue(accountInfoElement.isDisplayed(), "Account information is not displayed");
        System.out.println("account Info: " + accountInfoElement.getText());


        // Test the visibility of the membership information element
        WebElement membershipElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[1]/div[1]")));
        Assert.assertTrue(membershipElement.isDisplayed(), "Membership information is not displayed");
        System.out.println("Membership Details: " + membershipElement.getText());


        // Test the visibility of the plan details element
        WebElement planDetailsElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[1]/div[2]/div")));
        Assert.assertTrue(planDetailsElement.isDisplayed(), "Plan details are not displayed");
        System.out.println("Plan Details: " + planDetailsElement.getText());

    }

    @Test (priority = 2)
    public void testLogoutFunctionality() {

        // Navigate to the Account page
        driver.get("https://qamoviesapp.ccbp.tech/account");

        // Click on the logout button
        WebElement logoutButtonEl = driver.findElement(By.className("logout-button"));
        logoutButtonEl.click();

        // Verify that the login page is displayed after logout
        WebElement loginForm = driver.findElement(By.className("login-form"));
        Assert.assertTrue(loginForm.isDisplayed(), "Logout failed. Login form not displayed.");

        // Print statement for verification
        if (loginForm.isDisplayed()) {
            System.out.println("Logout successful. User navigated to the login page.");
        } else {
            System.out.println("Logout failed. User not on the login page.");
        }

        // Navigate to the Login page
        driver.get("https://qamoviesapp.ccbp.tech/login");
    }


    @AfterClass
    public void tearDown() {
        // Close the browser window
        if (driver != null) {
            driver.quit();
        }
    }
}
