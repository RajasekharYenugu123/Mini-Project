package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class LoginPageTest {
    public WebDriver driver;

    @BeforeMethod
    public void setup() {
        // Setting up driver instance
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rajasekhar\\Downloads\\chromedriver-win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://qamoviesapp.ccbp.tech/login");
    }

    @Test(priority = 1)
    public void testLogoImageDisplayed() {
        try {
            WebElement logoImage = driver.findElement(By.id("login-website-logo"));
            Assert.assertTrue(logoImage.isDisplayed(), "Logo image is not displayed");
        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Logo image element not found: " + e.getMessage());
        }
    }

    @Test(priority = 2)
    public void testHeadingText() {
        try {
            WebElement heading = driver.findElement(By.tagName("sign-in-heading"));
            Assert.assertEquals(heading.getText(), "Login", "Heading text is incorrect");
        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Heading element not found: " + e.getMessage());
        }
    }

    @Test(priority = 3)
    public void testUsernameLabelText() {
        try {
            WebElement usernameLabel = driver.findElement(By.xpath("input-label"));
            Assert.assertTrue(usernameLabel.isDisplayed(), "Username label is not displayed");
        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Username label element not found: " + e.getMessage());
        }
    }

    @Test(priority = 4)
    public void testPasswordLabelText() {
        try {
            WebElement passwordLabel = driver.findElement(By.xpath("input-label"));
            Assert.assertTrue(passwordLabel.isDisplayed(), "Password label is not displayed");
        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Password label element not found: " + e.getMessage());
        }
    }

    @Test(priority = 5)
    public void testLoginButton() {
        try {
            WebElement loginButton = driver.findElement(By.className("login-button"));
            Assert.assertTrue(loginButton.isDisplayed(), "Login button is not displayed");
        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Login button element not found: " + e.getMessage());
        }
    }

    @Test(priority = 6)
    public void loginWithEmptyFields() {
        try {
            WebElement loginButtonEl = driver.findElement(By.className("login-button"));
            loginButtonEl.submit();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("error-message")));

            try {
                WebElement errorMessageEl = driver.findElement(By.className("error-message"));
                String errorMessage = errorMessageEl.getText();
                Assert.assertEquals(errorMessage, "*Username or password is invalid");
            } catch (org.openqa.selenium.NoSuchElementException e) {
                System.out.println("Login successful with empty fields");
            }

        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Element not found: " + e.getMessage());
        }
    }

    @Test(priority = 7)
    public void loginWithEmptyUsername() {
        try {
            WebElement passwordEl = driver.findElement(By.id("passwordInput"));
            passwordEl.sendKeys("rahul@2021");

            WebElement loginButtonEl = driver.findElement(By.className("login-button"));
            loginButtonEl.submit();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("error-message")));

            try {
                WebElement errorMessageEl = driver.findElement(By.className("error-message"));
                String errorMessage = errorMessageEl.getText();
                Assert.assertEquals(errorMessage, "*Username or password is invalid");
            } catch (org.openqa.selenium.NoSuchElementException e) {
                System.out.println("Login successful with empty username");
            }

        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Element not found: " + e.getMessage());
        }
    }


    @Test(priority = 8)
    public void loginWithEmptyPassword() {
        try {
            WebElement usernameEl = driver.findElement(By.id("usernameInput"));
            usernameEl.sendKeys("rahul");

            WebElement loginButtonEl = driver.findElement(By.className("login-button"));
            loginButtonEl.submit();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("error-message")));

            try {
                WebElement errorMessageEl = driver.findElement(By.className("error-message"));
                String errorMessage = errorMessageEl.getText();
                Assert.assertEquals(errorMessage, "*Username or password is invalid");
            } catch (org.openqa.selenium.NoSuchElementException e) {
                System.out.println("Login successful with empty password");
            }

        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Element not found: " + e.getMessage());
        }
    }


    @Test(priority = 9)
    public void loginWithValidCredentials() {
        try {
            WebElement usernameEl = driver.findElement(By.id("usernameInput"));
            usernameEl.sendKeys("rahul");

            WebElement passwordEl = driver.findElement(By.id("passwordInput"));
            passwordEl.sendKeys("rahul@2021");

            WebElement loginButtonEl = driver.findElement(By.className("login-button"));
            loginButtonEl.submit();

            String expectedUrl = "https://qamoviesapp.ccbp.tech/";

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.urlToBe(expectedUrl));

            String currentUrl = driver.getCurrentUrl();
            Assert.assertEquals(expectedUrl, currentUrl, "Urls do not match");

        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Element not found: " + e.getMessage());
        }
    }

    @Test(priority = 10)
    public void loginWithInvalidCredentials() {
        try {
            WebElement usernameEl = driver.findElement(By.id("usernameInput"));
            usernameEl.sendKeys("rahul");

            WebElement passwordEl = driver.findElement(By.id("passwordInput"));
            passwordEl.sendKeys("rahul2021");

            WebElement loginButtonEl = driver.findElement(By.className("login-button"));
            loginButtonEl.submit();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.className("error-message")));

            WebElement errorMessageEl = driver.findElement(By.className("error-message"));
            String errorMessage = errorMessageEl.getText();

            Assert.assertEquals(errorMessage, "username and password didn't match");

        } catch (org.openqa.selenium.NoSuchElementException e) {
            System.out.println("Element not found: " + e.getMessage());
        }
    }

    @AfterMethod
    public void teardown() {

        driver.quit();
    }
}
