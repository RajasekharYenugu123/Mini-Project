package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import org.testng.Assert;

import java.time.Duration;

public class HeaderSectionTest {
    public WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rajasekhar\\Downloads\\chromedriver-win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://qamoviesapp.ccbp.tech/login");

        WebElement usernameEl = driver.findElement(By.id("usernameInput"));
        usernameEl.sendKeys("rahul");

        WebElement passwordEl = driver.findElement(By.id("passwordInput"));
        passwordEl.sendKeys("rahul@2021");

        WebElement loginButtonEl = driver.findElement(By.className("login-button"));
        loginButtonEl.submit();
    }

    @Test(priority = 1)
    public void testWebsiteLogoDisplayed() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement logo = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[1]/nav/div[1]/a/img")));
        Assert.assertTrue(logo.isDisplayed(), "Website logo is not displayed");
    }

    @Test(priority = 2)
    public void testNavbarElements() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Assuming the navbar elements are in a specific class
        WebElement homeLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@class, 'nav-link active-nav-link')]")));
        WebElement popularLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@class, 'nav-link')]")));
        WebElement searchLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class, 'search-account-container')]")));


        Assert.assertTrue(homeLink.isDisplayed(), "Home link is not displayed");
        Assert.assertTrue(popularLink.isDisplayed(), "Popular link is not displayed");
        Assert.assertTrue(searchLink.isDisplayed(), "Search link is not displayed");
    }
    @Test(priority = 3)
    public void testNavigationToHomePage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement homeLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[1]/nav/div[1]/ul/li[1]/a")));
        homeLink.click();
    }
     @Test(priority = 4)
     public  void testNavigationToPopularPage (){
         WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

         WebElement popularLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href=\"/popular\"]")));

         popularLink.click();


    }
    @Test(priority = 5)
    public void testNavigationToAccountPage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Navigate to the page
        driver.get("https://qamoviesapp.ccbp.tech/account");

        // Locate the button element
        WebElement avatarButton = driver.findElement(By.className("avatar-button"));

        // Perform an action on the button and click
        avatarButton.click();
    }
    @Test(priority = 6)
    public void testSearchIconVisibility() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        By buttonLocator = By.className("search-empty-button");

        WebElement searchButton = wait.until(ExpectedConditions.visibilityOfElementLocated(buttonLocator));

        searchButton.click();

    }


    @AfterMethod
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
