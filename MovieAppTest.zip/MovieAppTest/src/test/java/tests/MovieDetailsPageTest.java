package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



import org.testng.Assert;
import java.time.Duration;

public class MovieDetailsPageTest {

    private WebDriver driver;

    @BeforeClass
    public void setUp() {
        // Set the path to your ChromeDriver executable
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rajasekhar\\Downloads\\chromedriver-win32\\chromedriver.exe");
        // Initialize ChromeDriver
        driver = new ChromeDriver();
        // Navigate to the search page or your application's home page
        driver.get("https://qamoviesapp.ccbp.tech/login");

        // Perform login (you can modify this part based on your authentication mechanism)
        WebElement usernameEl = driver.findElement(By.id("usernameInput"));
        usernameEl.sendKeys("rahul");

        WebElement passwordEl = driver.findElement(By.id("passwordInput"));
        passwordEl.sendKeys("rahul@2021");

        WebElement loginButtonEl = driver.findElement(By.className("login-button"));
        loginButtonEl.submit();
    }

    @Test
    public void testMovieDetailsPageUIElements() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));


        // Click on any movie
        WebElement movieLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='root']/div/div[2]/div[1]/div/div/div/div/div[1]/div/a")));
        movieLink.click();

        // Wait for the movie details page to load
        String expectedTitle = "movie-title";  // Replace with the actual title
        System.out.println("Waiting for the title to contain: " + expectedTitle);

        try {
            WebElement movieTitleElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("movie-title")));
            System.out.println("Movie Title: " + movieTitleElement.getText());
        } catch (TimeoutException e) {
            System.out.println("TimeoutException: Movie title element not found within the specified timeout.");
            throw e;
        }
        WebElement movieDescription = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[1]/p"));
        Assert.assertTrue(movieDescription.isDisplayed(), "Movie description is not displayed");
        System.out.println("Movie Description: " + movieDescription.getText());

    }
    @Test
    public void testMovieDetailsPageUIElementsAfterClickingOnPopularMovie() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Navigate to the Popular page
        driver.get("https://qamoviesapp.ccbp.tech/popular");

        // Click on any popular movie
        WebElement popularMovieLink = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"root\"]/div/div[1]/li[1]/a")));
        popularMovieLink.click();

        // Wait for the movie details page to load
        String expectedTitle = "movie-title";  // Replace with the actual title
        System.out.println("Waiting for the title to contain: " + expectedTitle);

        try {
            WebElement movieTitleElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("movie-title")));
            System.out.println("Movie Title: " + movieTitleElement.getText());
        } catch (TimeoutException e) {
            System.out.println("TimeoutException: Movie title element not found within the specified timeout.");
            throw e;
        }

        // Add assertions and print statements for other UI elements on the Movie Details Page
        WebElement movieDescription = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[1]/p"));
        Assert.assertTrue(movieDescription.isDisplayed(), "Movie description is not displayed");
        System.out.println("Movie Description: " + movieDescription.getText());

    }
    @AfterClass
    public void tearDown() {
        // Close the browser window
        if (driver != null) {
            driver.quit();
        }
    }
}
