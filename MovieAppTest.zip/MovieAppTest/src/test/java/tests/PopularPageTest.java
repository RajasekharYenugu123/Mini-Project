package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

public class PopularPageTest {
    private WebDriver driver;

    @BeforeMethod
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rajasekhar\\Downloads\\chromedriver-win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://qamoviesapp.ccbp.tech/login");

        WebElement usernameEl = driver.findElement(By.id("usernameInput"));
        usernameEl.sendKeys("rahul");

        WebElement passwordEl = driver.findElement(By.id("passwordInput"));
        passwordEl.sendKeys("rahul@2021");

        WebElement loginButtonEl = driver.findElement(By.className("login-button"));
        loginButtonEl.submit();
    }

    @Test(priority = 1)
    public void testPopularPageUI() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get("https://qamoviesapp.ccbp.tech/popular");
        WebElement popularLink = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("nav-link")));
        popularLink.click();
        driver.switchTo().defaultContent();

    }

        @Test(priority = 2)
    public void testMoviesAreDisplayed() {
        // Test whether movies are displayed on the popular page
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            driver.get("https://qamoviesapp.ccbp.tech/popular");

        List<WebElement> movieElements = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".movie-image")));
        Assert.assertFalse(movieElements.isEmpty(), "No movies are displayed on the popular page");


    }

    @AfterMethod
    public void teardown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
